=== PAM Probetermine ===
Contributors: curaggi
Requires at least: 6.0
Tested up to: 6.6
Stable tag: 1.0.0
License: GPLv2 or later

Internes Plugin zur Verwaltung von kostenlosen Testbehandlungen.
Shortcodes:
[probe_form]
[probe_search]
