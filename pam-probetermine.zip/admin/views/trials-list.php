<?php
// Trials list with inline-status placeholder
