<?php
// Inline status edit placeholder
