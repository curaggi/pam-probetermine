<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PAM_Deactivator {
    public static function deactivate() {
        // Tabellen bewusst nicht löschen
    }
}
